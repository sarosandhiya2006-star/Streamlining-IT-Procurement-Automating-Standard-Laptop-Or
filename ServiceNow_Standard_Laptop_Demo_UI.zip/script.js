let count=1;
document.getElementById('requestForm').addEventListener('submit',function(e){
  e.preventDefault();
  count++;
  const n=document.getElementById('name').value;
  const id=document.getElementById('empid').value;
  const dept=document.getElementById('dept').value;
  const model=document.getElementById('model').value;
  const ritm='RITM00100'+(count+1);
  const task='SCTASK00100'+(count+1);
  document.getElementById('requestId').textContent=ritm;
  document.getElementById('taskTable').innerHTML=
    `<tr><td>${task}</td><td>${ritm}</td><td>Configure ${model}</td><td>Hardware</td><td><span class="status">Open</span></td></tr>`;
  document.getElementById('total').textContent=count;
  document.getElementById('approved').textContent=count;
  document.getElementById('tasksCount').textContent=count;
  alert(`Request submitted successfully!\n\nEmployee: ${n}\nEmployee ID: ${id}\nDepartment: ${dept}\nRITM: ${ritm}\nCatalog Task: ${task}\nAssignment Group: Hardware`);
  this.reset();
});
